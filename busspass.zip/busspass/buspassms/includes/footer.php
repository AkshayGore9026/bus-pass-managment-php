
	<div class="copy-right"> 
		<div class="container">
			<p>© 2022 Bus Pass Management System</p>
		</div> 
	</div> 
	<!-- //footer -->   
	